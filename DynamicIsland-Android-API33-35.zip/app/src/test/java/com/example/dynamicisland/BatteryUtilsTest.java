package com.example.dynamicisland;

import org.junit.Test;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.assertFalse;

public class BatteryUtilsTest {

    @Test
    public void calculatesBatteryPercentage() {
        assertEquals(50, BatteryUtils.percentage(50, 100));
        assertEquals(75, BatteryUtils.percentage(3, 4));
        assertEquals(100, BatteryUtils.percentage(120, 100));
        assertEquals(0, BatteryUtils.percentage(0, 100));
    }

    @Test
    public void handlesInvalidBatteryData() {
        assertEquals(-1, BatteryUtils.percentage(-1, 100));
        assertEquals(-1, BatteryUtils.percentage(50, 0));
        assertEquals(-1, BatteryUtils.percentage(50, -5));
    }

    @Test
    public void detectsChargingStates() {
        // BatteryManager.BATTERY_STATUS_CHARGING = 2
        assertTrue(BatteryUtils.isChargingOrFull(2));
        // BatteryManager.BATTERY_STATUS_FULL = 5
        assertTrue(BatteryUtils.isChargingOrFull(5));
        // BatteryManager.BATTERY_STATUS_DISCHARGING = 3
        assertFalse(BatteryUtils.isChargingOrFull(3));
        // BatteryManager.BATTERY_STATUS_NOT_CHARGING = 4
        assertFalse(BatteryUtils.isChargingOrFull(4));
        // BatteryManager.BATTERY_STATUS_UNKNOWN = 1
        assertFalse(BatteryUtils.isChargingOrFull(1));
    }
}
