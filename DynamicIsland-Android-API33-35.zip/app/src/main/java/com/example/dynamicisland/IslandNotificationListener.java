package com.example.dynamicisland;

import android.app.Notification;
import android.content.ComponentName;
import android.content.Context;
import android.provider.Settings;
import android.service.notification.NotificationListenerService;
import android.service.notification.StatusBarNotification;

public class IslandNotificationListener extends NotificationListenerService {

    public static boolean hasAccess(Context context) {
        String enabled = Settings.Secure.getString(
                context.getContentResolver(),
                "enabled_notification_listeners"
        );

        if (enabled == null) {
            return false;
        }

        ComponentName component = new ComponentName(
                context,
                IslandNotificationListener.class
        );

        return enabled.contains(component.flattenToString());
    }

    @Override
    public void onNotificationPosted(StatusBarNotification sbn) {
        if (sbn == null || sbn.getNotification() == null) {
            return;
        }

        if (getPackageName().equals(sbn.getPackageName())) {
            return;
        }

        Notification notification = sbn.getNotification();

        CharSequence title = notification.extras.getCharSequence(
                Notification.EXTRA_TITLE
        );

        CharSequence text = notification.extras.getCharSequence(
                Notification.EXTRA_BIG_TEXT
        );

        if (text == null) {
            text = notification.extras.getCharSequence(
                    Notification.EXTRA_TEXT
            );
        }

        IslandService service = IslandService.getInstance();
        if (service != null) {
            service.onExternalNotification(
                    title == null ? "New notification" : title.toString(),
                    text == null ? "" : text.toString(),
                    sbn.getPackageName()
            );
        }
    }

    @Override
    public void onNotificationRemoved(StatusBarNotification sbn) {
        // Notification removal can be handled here if needed.
        // Do not clear a newer notification just because an older
        // notification was dismissed.
    }
}
