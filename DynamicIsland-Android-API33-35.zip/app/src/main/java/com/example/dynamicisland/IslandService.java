package com.example.dynamicisland;

import android.animation.ValueAnimator;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.graphics.drawable.GradientDrawable;
import android.media.MediaMetadata;
import android.media.session.MediaController;
import android.media.session.MediaSessionManager;
import android.media.session.PlaybackState;
import android.os.BatteryManager;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.util.DisplayMetrics;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.view.animation.OvershootInterpolator;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.List;

public class IslandService extends Service {

    private static final String CHANNEL_ID = "dynamic_island_channel";
    private static final int NOTIFICATION_ID = 1001;

    private static IslandService instance;

    private WindowManager windowManager;
    private FrameLayout islandRoot;
    private WindowManager.LayoutParams windowParams;

    private boolean isExpanded = false;
    private final Handler mainHandler = new Handler(Looper.getMainLooper());

    // UI dimensions
    private int collapsedWidth;
    private int collapsedHeight;
    private int expandedWidth;
    private int expandedHeight;
    private int cornerRadius;

    // Island Content views
    private FrameLayout containerView;
    private LinearLayout compactLayout;
    private LinearLayout expandedLayout;
    private TextView compactLeftText;
    private TextView compactRightText;
    private TextView expandedTitle;
    private TextView expandedSubtitle;
    private TextView expandedDetail;

    // State data
    private String currentTitle = "Dynamic Island";
    private String currentSubtitle = "Ready";
    private int currentBatteryPercent = 100;
    private boolean isCharging = false;
    private String currentTrack = "";
    private String currentArtist = "";
    private boolean isPlayingMusic = false;

    // Services & Receivers
    private MediaSessionManager mediaSessionManager;
    private MediaController activeMediaController;
    private Vibrator vibrator;

    public static IslandService getInstance() {
        return instance;
    }

    private final BroadcastReceiver batteryReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            if (intent == null) return;

            int level = intent.getIntExtra(BatteryManager.EXTRA_LEVEL, -1);
            int scale = intent.getIntExtra(BatteryManager.EXTRA_SCALE, -1);
            int status = intent.getIntExtra(BatteryManager.EXTRA_STATUS, -1);

            int percent = BatteryUtils.percentage(level, scale);
            boolean charging = BatteryUtils.isChargingOrFull(status);

            if (percent != -1) {
                currentBatteryPercent = percent;
            }

            if (charging != isCharging) {
                isCharging = charging;
                onBatteryEvent(currentBatteryPercent, isCharging);
            }
        }
    };

    private final MediaSessionManager.OnActiveSessionsChangedListener sessionsListener =
            new MediaSessionManager.OnActiveSessionsChangedListener() {
                @Override
                public void onActiveSessionsChanged(List<MediaController> controllers) {
                    updateActiveMediaSession(controllers);
                }
            };

    @Override
    public void onCreate() {
        super.onCreate();
        instance = this;
        vibrator = (Vibrator) getSystemService(Context.VIBRATOR_SERVICE);

        initDimensions();
        createNotificationChannel();
        startForeground(NOTIFICATION_ID, buildForegroundNotification());

        setupFloatingIsland();
        registerBatteryReceiver();
        registerMediaListener();
    }

    private int dp(float value) {
        DisplayMetrics dm = getResources().getDisplayMetrics();
        return (int) (value * dm.density + 0.5f);
    }

    private void initDimensions() {
        collapsedWidth = dp(160);
        collapsedHeight = dp(36);
        expandedWidth = dp(340);
        expandedHeight = dp(150);
        cornerRadius = dp(24);
    }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(
                    CHANNEL_ID,
                    "Dynamic Island Service",
                    NotificationManager.IMPORTANCE_LOW
            );
            channel.setDescription("Shows active pill overlay on screen");
            NotificationManager manager = getSystemService(NotificationManager.class);
            if (manager != null) {
                manager.createNotificationChannel(channel);
            }
        }
    }

    private Notification buildForegroundNotification() {
        Notification.Builder builder;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            builder = new Notification.Builder(this, CHANNEL_ID);
        } else {
            builder = new Notification.Builder(this);
        }

        return builder
                .setContentTitle("Dynamic Island Active")
                .setContentText("Tap overlay to expand or interact")
                .setSmallIcon(android.R.drawable.ic_dialog_info)
                .setOngoing(true)
                .build();
    }

    private void setupFloatingIsland() {
        windowManager = (WindowManager) getSystemService(WINDOW_SERVICE);

        int layoutFlag;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            layoutFlag = WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY;
        } else {
            layoutFlag = WindowManager.LayoutParams.TYPE_PHONE;
        }

        windowParams = new WindowManager.LayoutParams(
                collapsedWidth,
                collapsedHeight,
                layoutFlag,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                        | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
                        | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT
        );

        windowParams.gravity = Gravity.TOP | Gravity.CENTER_HORIZONTAL;
        windowParams.y = dp(12);

        islandRoot = new FrameLayout(this);
        containerView = new FrameLayout(this);

        GradientDrawable bg = new GradientDrawable();
        bg.setColor(Color.BLACK);
        bg.setCornerRadius(cornerRadius);
        containerView.setBackground(bg);
        containerView.setClipToOutline(true);

        setupCompactLayout();
        setupExpandedLayout();

        containerView.addView(compactLayout);
        containerView.addView(expandedLayout);

        FrameLayout.LayoutParams containerParams = new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT
        );
        islandRoot.addView(containerView, containerParams);

        setupTouchGestures();
        windowManager.addView(islandRoot, windowParams);
    }

    private void setupCompactLayout() {
        compactLayout = new LinearLayout(this);
        compactLayout.setOrientation(LinearLayout.HORIZONTAL);
        compactLayout.setGravity(Gravity.CENTER_VERTICAL);
        compactLayout.setPadding(dp(12), 0, dp(12), 0);

        compactLeftText = new TextView(this);
        compactLeftText.setText("⚡ 100%");
        compactLeftText.setTextColor(Color.WHITE);
        compactLeftText.setTextSize(12);

        View spacer = new View(this);
        LinearLayout.LayoutParams spacerParams = new LinearLayout.LayoutParams(0, 1, 1f);

        compactRightText = new TextView(this);
        compactRightText.setText("Island");
        compactRightText.setTextColor(Color.LTGRAY);
        compactRightText.setTextSize(12);

        compactLayout.addView(compactLeftText);
        compactLayout.addView(spacer, spacerParams);
        compactLayout.addView(compactRightText);
    }

    private void setupExpandedLayout() {
        expandedLayout = new LinearLayout(this);
        expandedLayout.setOrientation(LinearLayout.VERTICAL);
        expandedLayout.setPadding(dp(16), dp(14), dp(16), dp(14));
        expandedLayout.setVisibility(View.GONE);

        expandedTitle = new TextView(this);
        expandedTitle.setText("Dynamic Island");
        expandedTitle.setTextColor(Color.WHITE);
        expandedTitle.setTextSize(16);

        expandedSubtitle = new TextView(this);
        expandedSubtitle.setText("Active service");
        expandedSubtitle.setTextColor(Color.LTGRAY);
        expandedSubtitle.setTextSize(13);

        expandedDetail = new TextView(this);
        expandedDetail.setText("Battery: 100% | System Normal");
        expandedDetail.setTextColor(Color.GRAY);
        expandedDetail.setTextSize(12);
        expandedDetail.setPadding(0, dp(8), 0, 0);

        expandedLayout.addView(expandedTitle);
        expandedLayout.addView(expandedSubtitle);
        expandedLayout.addView(expandedDetail);
    }

    private void setupTouchGestures() {
        islandRoot.setOnTouchListener(new View.OnTouchListener() {
            private float startY;
            private long startTime;

            @Override
            public boolean onTouch(View v, MotionEvent event) {
                switch (event.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        startY = event.getRawY();
                        startTime = System.currentTimeMillis();
                        return true;

                    case MotionEvent.ACTION_UP:
                        float diffY = event.getRawY() - startY;
                        long duration = System.currentTimeMillis() - startTime;

                        if (Math.abs(diffY) < dp(10) && duration < 300) {
                            toggleExpand();
                        } else if (diffY < -dp(30) && isExpanded) {
                            collapseIsland();
                        }
                        return true;
                }
                return false;
            }
        });
    }

    private void toggleExpand() {
        if (isExpanded) {
            collapseIsland();
        } else {
            expandIsland();
        }
    }

    private void triggerHaptic() {
        if (vibrator != null) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                vibrator.vibrate(VibrationEffect.createOneShot(25, VibrationEffect.DEFAULT_AMPLITUDE));
            } else {
                vibrator.vibrate(25);
            }
        }
    }

    private void expandIsland() {
        if (isExpanded) return;
        isExpanded = true;
        triggerHaptic();

        compactLayout.setVisibility(View.GONE);
        expandedLayout.setVisibility(View.VISIBLE);

        animateIslandSize(collapsedWidth, expandedWidth, collapsedHeight, expandedHeight, dp(24), dp(32));
    }

    private void collapseIsland() {
        if (!isExpanded) return;
        isExpanded = false;
        triggerHaptic();

        expandedLayout.setVisibility(View.GONE);
        compactLayout.setVisibility(View.VISIBLE);

        animateIslandSize(expandedWidth, collapsedWidth, expandedHeight, collapsedHeight, dp(32), dp(24));
    }

    private void animateIslandSize(int fromW, int toW, int fromH, int toH, float fromR, float toR) {
        ValueAnimator animator = ValueAnimator.ofFloat(0f, 1f);
        animator.setDuration(280);
        animator.setInterpolator(new OvershootInterpolator(0.85f));

        animator.addUpdateListener(animation -> {
            float fraction = (float) animation.getAnimatedValue();
            windowParams.width = (int) (fromW + (toW - fromW) * fraction);
            windowParams.height = (int) (fromH + (toH - fromH) * fraction);

            GradientDrawable bg = (GradientDrawable) containerView.getBackground();
            bg.setCornerRadius(fromR + (toR - fromR) * fraction);

            if (islandRoot.isAttachedToWindow()) {
                windowManager.updateViewLayout(islandRoot, windowParams);
            }
        });

        animator.start();
    }

    public void onExternalNotification(String title, String text, String packageName) {
        mainHandler.post(() -> {
            currentTitle = title;
            currentSubtitle = text;

            compactLeftText.setText("🔔 " + (packageName.length() > 8 ? packageName.substring(0, 8) : packageName));
            compactRightText.setText(title);

            expandedTitle.setText(title);
            expandedSubtitle.setText(text);
            expandedDetail.setText("From: " + packageName);

            expandIsland();

            // Auto-collapse after 4 seconds
            mainHandler.removeCallbacksAndMessages(null);
            mainHandler.postDelayed(this::collapseIsland, 4000);
        });
    }

    private void onBatteryEvent(int percent, boolean charging) {
        mainHandler.post(() -> {
            String batteryText = (charging ? "⚡ " : "🔋 ") + percent + "%";
            compactLeftText.setText(batteryText);

            expandedTitle.setText(charging ? "Charging Connected" : "Battery Update");
            expandedSubtitle.setText(batteryText + (charging ? " (Fast Charging)" : ""));
            expandedDetail.setText("Current battery health: Normal");

            expandIsland();
            mainHandler.postDelayed(this::collapseIsland, 3500);
        });
    }

    private void registerBatteryReceiver() {
        IntentFilter filter = new IntentFilter(Intent.ACTION_BATTERY_CHANGED);
        registerReceiver(batteryReceiver, filter);
    }

    private void registerMediaListener() {
        try {
            ComponentName compName = new ComponentName(this, IslandNotificationListener.class);
            mediaSessionManager = (MediaSessionManager) getSystemService(Context.MEDIA_SESSION_SERVICE);
            if (mediaSessionManager != null && IslandNotificationListener.hasAccess(this)) {
                mediaSessionManager.addOnActiveSessionsChangedListener(sessionsListener, compName);
                updateActiveMediaSession(mediaSessionManager.getActiveSessions(compName));
            }
        } catch (SecurityException ignored) {
            // Handled when user has not yet allowed notification listener access
        }
    }

    private void updateActiveMediaSession(List<MediaController> controllers) {
        if (controllers != null && !controllers.isEmpty()) {
            activeMediaController = controllers.get(0);
            MediaMetadata metadata = activeMediaController.getMetadata();
            if (metadata != null) {
                currentTrack = metadata.getString(MediaMetadata.METADATA_KEY_TITLE);
                currentArtist = metadata.getString(MediaMetadata.METADATA_KEY_ARTIST);
            }

            PlaybackState state = activeMediaController.getPlaybackState();
            isPlayingMusic = (state != null && state.getState() == PlaybackState.STATE_PLAYING);

            if (isPlayingMusic) {
                compactLeftText.setText("🎵 " + (currentTrack != null ? currentTrack : "Playing"));
                compactRightText.setText("▶");
            }
        }
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        instance = null;

        if (batteryReceiver != null) {
            try {
                unregisterReceiver(batteryReceiver);
            } catch (Exception ignored) {}
        }

        if (mediaSessionManager != null && sessionsListener != null) {
            try {
                mediaSessionManager.removeOnActiveSessionsChangedListener(sessionsListener);
            } catch (Exception ignored) {}
        }

        if (islandRoot != null && islandRoot.isAttachedToWindow() && windowManager != null) {
            windowManager.removeView(islandRoot);
        }
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
}
