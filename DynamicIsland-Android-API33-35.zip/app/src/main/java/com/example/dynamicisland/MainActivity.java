package com.example.dynamicisland;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

public class MainActivity extends Activity {

    private LinearLayout root;
    private TextView permissionStatus;

    private int dp(float value) {
        return (int) (value * getResources().getDisplayMetrics().density + 0.5f);
    }

    private LinearLayout.LayoutParams fullWidth(int height) {
        return new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                height < 0 ? height : dp(height)
        );
    }

    private Button addButton(String label, Runnable action) {
        Button button = new Button(this);
        button.setText(label);

        LinearLayout.LayoutParams params = fullWidth(54);
        params.setMargins(0, dp(6), 0, dp(6));
        root.addView(button, params);

        button.setOnClickListener(v -> action.run());
        return button;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(22), dp(24), dp(22), dp(24));
        root.setGravity(Gravity.CENTER_VERTICAL);

        TextView title = new TextView(this);
        title.setText("Dynamic Island");
        title.setTextSize(28);
        title.setGravity(Gravity.CENTER);
        root.addView(title, fullWidth(64));

        TextView description = new TextView(this);
        description.setText(
                "A floating island for notifications, battery status " +
                "and supported media sessions."
        );
        description.setTextSize(15);
        description.setGravity(Gravity.CENTER);
        root.addView(description, fullWidth(80));

        permissionStatus = new TextView(this);
        permissionStatus.setTextSize(14);
        permissionStatus.setPadding(0, dp(12), 0, dp(12));
        root.addView(permissionStatus, fullWidth(-2));

        addButton("1. Enable Overlay", () -> {
            if (!Settings.canDrawOverlays(this)) {
                Intent intent = new Intent(
                        Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:" + getPackageName())
                );
                startActivity(intent);
            } else {
                refreshStatus();
            }
        });

        addButton("2. Enable Notification Access", () -> {
            startActivity(new Intent(
                    Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS
            ));
        });

        addButton("3. Allow Notifications", () -> {
            if (Build.VERSION.SDK_INT >= 33 &&
                    checkSelfPermission(
                            Manifest.permission.POST_NOTIFICATIONS
                    ) != PackageManager.PERMISSION_GRANTED) {

                requestPermissions(
                        new String[]{
                                Manifest.permission.POST_NOTIFICATIONS
                        },
                        100
                );
            } else {
                refreshStatus();
            }
        });

        addButton("Start Dynamic Island", this::startIsland);

        addButton("Stop Dynamic Island", () -> {
            stopService(new Intent(this, IslandService.class));
            refreshStatus();
        });

        setContentView(root);
        refreshStatus();
    }

    private void startIsland() {
        if (!Settings.canDrawOverlays(this)) {
            startActivity(new Intent(
                    Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:" + getPackageName())
            ));
            return;
        }

        Intent intent = new Intent(this, IslandService.class);

        if (Build.VERSION.SDK_INT >= 26) {
            startForegroundService(intent);
        } else {
            startService(intent);
        }

        refreshStatus();
    }

    private void refreshStatus() {
        if (permissionStatus == null) {
            return;
        }

        boolean overlay = Settings.canDrawOverlays(this);

        permissionStatus.setText(
                "Overlay: " + (overlay ? "Enabled ✓" : "Not enabled ✗") +
                "\nNotification Access: " +
                (IslandNotificationListener.hasAccess(this)
                        ? "Enabled ✓" : "Not enabled ✗") +
                "\nNotification display permission: " +
                (Build.VERSION.SDK_INT < 33 ||
                 checkSelfPermission(
                         Manifest.permission.POST_NOTIFICATIONS
                 ) == PackageManager.PERMISSION_GRANTED
                        ? "Granted ✓" : "Not granted ✗")
        );
    }

    @Override
    protected void onResume() {
        super.onResume();
        refreshStatus();
    }
}
