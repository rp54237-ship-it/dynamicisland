package com.example.dynamicisland;

public final class BatteryUtils {

    private BatteryUtils() {
    }

    /**
     * Calculates the battery percentage given level and scale.
     * Returns -1 if inputs are invalid.
     */
    public static int percentage(int level, int scale) {
        if (level < 0 || scale <= 0) {
            return -1;
        }

        return Math.max(
                0,
                Math.min(100, Math.round(level * 100f / scale))
        );
    }

    /**
     * Checks if the device is currently in a charging or full state.
     * Android BatteryManager status:
     * 2 = BATTERY_STATUS_CHARGING
     * 5 = BATTERY_STATUS_FULL
     */
    public static boolean isChargingOrFull(int status) {
        return status == 2 || status == 5;
    }
}
